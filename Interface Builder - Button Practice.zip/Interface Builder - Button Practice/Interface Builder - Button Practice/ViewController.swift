//
//  ViewController.swift
//  Interface Builder - Button Practice
//
//  Created by Butts, Robert on 5/12/22.
//

import UIKit

class ViewController: UIViewController {

    
    //Reference to our label object which will display our random numbers
    @IBOutlet var label: UILabel!
    //
    @IBOutlet var buttonColor: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    /*  Function for when the user presses the Random Number button.  It uses the random method to assign a random integer between 1 and 100 then assign it to the randomNumber constant.  That random number is then assigned to our label which we created on line 15 */
    @IBAction func randomNumber(_ sender: Any) {
        let randomNumber = Int.random(in:1...100)
        label.text = String(randomNumber)
    }
    
    /*  Function for when the user presses the Change Background Color button.  It uses the random method to assign a random double between 0.0 and 1.0 to each color value.   */
    @IBAction func changeBackgroundColor(_ sender: Any) {
        
        let redValue = Double.random(in:0.0...1.0)
        let greenValue = Double.random(in:0.0...1.0)
        let blueValue = Double.random(in:0.0...1.0)
  
        /* Take the red, green, and blue values from above and input them into the UIColor function. Alpha represents the opacity of the color.  The UIColor function value is then assigned to the background color of the current view.  */
        self.view.backgroundColor = UIColor(red: redValue, green: greenValue, blue: blueValue, alpha: 1.0)
    }
    
    //Function for when the user presses the Change Button Color button.
    @IBAction func changeButtonColor(_ sender: Any) {
        
        let redValue = Double.random(in:0.0...1.0)
        let greenValue = Double.random(in:0.0...1.0)
        let blueValue = Double.random(in:0.0...1.0)
        
        /* We needed to create a new outlet on line 15 in order for the change in the button's background color to take effect.  Otherwise, this follows the same process that we highlighted in the changeBackgroundColor function.*/
        self.buttonColor.backgroundColor = UIColor(red: redValue, green: greenValue, blue: blueValue, alpha: 1.0)
    }
    
    
}

